import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { Restaurant, RestaurantUser, Subscription } from '@/lib/types';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  restaurant: Restaurant | null;
  restaurantUser: RestaurantUser | null;
  subscription: Subscription | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string, fullName: string, restaurantName: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [restaurantUser, setRestaurantUser] = useState<RestaurantUser | null>(null);
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [loading, setLoading] = useState(true);

  const loadProfile = useCallback(async (uid: string) => {
    const { data: ru, error: ruError } = await supabase
      .from('restaurant_users')
      .select('*')
      .eq('auth_user_id', uid)
      .maybeSingle();

    if (ruError || !ru) {
      setRestaurant(null);
      setRestaurantUser(null);
      setSubscription(null);
      return;
    }

    setRestaurantUser(ru as RestaurantUser);

    const { data: rest } = await supabase
      .from('restaurants')
      .select('*')
      .eq('id', ru.restaurant_id)
      .maybeSingle();
    setRestaurant(rest as Restaurant);

    const { data: sub } = await supabase
      .from('subscriptions')
      .select('*')
      .eq('restaurant_id', ru.restaurant_id)
      .maybeSingle();
    setSubscription(sub as Subscription);
  }, []);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: listener } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        (async () => {
          await loadProfile(session.user.id);
          setLoading(false);
        })();
      } else {
        setRestaurant(null);
        setRestaurantUser(null);
        setSubscription(null);
        setLoading(false);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, [loadProfile]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUp = async (email: string, password: string, fullName: string, restaurantName: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return { error: error.message };

    const userId = data.user?.id;
    if (!userId) return { error: 'Failed to create account.' };

    const { data: rest } = await supabase
      .from('restaurants')
      .insert({ name: restaurantName, email, status: 'active' })
      .select()
      .single();

    await supabase.from('restaurant_users').insert({
      restaurant_id: rest.id,
      auth_user_id: userId,
      full_name: fullName,
      email,
      role: 'owner',
      status: 'active',
    });

    await supabase.from('subscriptions').insert({
      restaurant_id: rest.id,
      plan: 'trial',
      status: 'trial',
      start_date: new Date().toISOString().slice(0, 10),
      expiry_date: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
      billing_cycle: 'monthly',
      amount: 0,
      auto_renewal: false,
      max_branches: 1,
      max_users: 3,
    });

    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setUser(null);
    setRestaurant(null);
    setRestaurantUser(null);
    setSubscription(null);
  };

  const refreshProfile = async () => {
    if (user) await loadProfile(user.id);
  };

  return (
    <AuthContext.Provider
      value={{ session, user, restaurant, restaurantUser, subscription, loading, signIn, signUp, signOut, refreshProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, ArrowUpFromLine } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { useToast } from '@/components/ui/Toast';
import { Button, Card, Select, Input, Badge } from '@/components/ui';
import { DataTable, Column } from '@/components/ui/DataTable';
import { Modal } from '@/components/ui/Modal';
import { PageHeader } from '@/components/PageHeader';
import { formatCurrency, formatDate, formatNumber } from '@/lib/utils';
import type { InventoryItem, StockIssue } from '@/lib/types';

interface IssueLine { item_id: string; item_name: string; quantity: string; unit: string; rate: string; }

const departments = ['Kitchen', 'Bar', 'Housekeeping', 'Service', 'Management'];
const reasons = ['Consumption', 'Breakage', 'Spillage', 'Transfer', 'Other'];

export function StockOutPage() {
  const { restaurant, restaurantUser } = useAuth();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<StockIssue[]>([]);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ department: 'Kitchen', reason: 'Consumption', issue_date: new Date().toISOString().slice(0, 10), notes: '' });
  const [lines, setLines] = useState<IssueLine[]>([]);

  const loadData = useCallback(async () => {
    if (!restaurant) return;
    const rid = restaurant.id;
    const [{ data: issueData }, { data: itemData }] = await Promise.all([
      supabase.from('stock_issues').select('*').eq('restaurant_id', rid).order('created_at', { ascending: false }),
      supabase.from('inventory_items').select('*, unit:units(*)').eq('restaurant_id', rid).order('name'),
    ]);
    setIssues((issueData as StockIssue[]) || []);
    setItems((itemData as InventoryItem[]) || []);
    setLoading(false);
  }, [restaurant]);

  useEffect(() => { loadData(); }, [loadData]);

  const addLine = () => setLines([...lines, { item_id: '', item_name: '', quantity: '', unit: '', rate: '' }]);
  const removeLine = (idx: number) => setLines(lines.filter((_, i) => i !== idx));
  const updateLine = (idx: number, field: keyof IssueLine, value: string) => {
    const next = [...lines];
    next[idx] = { ...next[idx], [field]: value };
    if (field === 'item_id') {
      const item = items.find((i) => i.id === value);
      if (item) { next[idx].item_name = item.name; next[idx].unit = item.unit?.symbol || ''; next[idx].rate = String(item.purchase_price); }
    }
    setLines(next);
  };

  const lineTotal = (l: IssueLine) => (parseFloat(l.quantity) || 0) * (parseFloat(l.rate) || 0);
  const grandTotal = lines.reduce((s, l) => s + lineTotal(l), 0);

  const handleSave = async () => {
    if (!restaurant || !restaurantUser) return;
    if (lines.length === 0 || lines.some((l) => !l.item_id || !l.quantity)) { toast('Add at least one valid item', 'error'); return; }
    for (const l of lines) {
      const item = items.find((i) => i.id === l.item_id);
      if (item && parseFloat(l.quantity) > item.current_stock) {
        toast(`Insufficient stock for ${l.item_name}. Available: ${item.current_stock} ${item.unit?.symbol}`, 'error');
        return;
      }
    }
    setSaving(true);
    const rid = restaurant.id;
    const count = issues.length + 1;
    const issueNumber = `ISS-${String(count).padStart(4, '0')}`;

    const { data: issue, error } = await supabase.from('stock_issues').insert({
      restaurant_id: rid, issue_number: issueNumber, issue_type: 'consumption',
      department: form.department, issue_date: form.issue_date,
      reason: form.reason, notes: form.notes || null, total_value: grandTotal,
      issued_by: restaurantUser.auth_user_id, issued_by_name: restaurantUser.full_name,
    }).select().single();

    if (error) { setSaving(false); toast('Unable to save.', 'error'); return; }

    for (const l of lines) {
      const item = items.find((i) => i.id === l.item_id);
      if (!item) continue;
      await supabase.from('stock_issue_items').insert({
        stock_issue_id: issue.id, restaurant_id: rid, item_id: l.item_id,
        item_name: l.item_name, quantity: parseFloat(l.quantity), unit: l.unit,
        rate: parseFloat(l.rate), total: lineTotal(l),
      });
      const newStock = item.current_stock - parseFloat(l.quantity);
      await supabase.from('inventory_items').update({ current_stock: newStock }).eq('id', l.item_id);
      await supabase.from('stock_transactions').insert({
        restaurant_id: rid, item_id: l.item_id, transaction_type: 'consumption',
        quantity_change: -parseFloat(l.quantity), quantity_after: newStock,
        reference_type: 'stock_issue', reference_id: issue.id,
        unit_cost: parseFloat(l.rate), reason: form.reason,
        performed_by: restaurantUser.auth_user_id, performed_by_name: restaurantUser.full_name,
      });
    }

    await supabase.from('activity_logs').insert({
      restaurant_id: rid, user_id: restaurantUser.auth_user_id, user_name: restaurantUser.full_name,
      module: 'stock_out', action: 'issue', description: `Issued stock via ${issueNumber} to ${form.department}`,
      ip_address: '103.21.45.67',
    });

    setSaving(false);
    toast(`${issueNumber} issued successfully.`, 'success');
    setShowModal(false);
    setForm({ department: 'Kitchen', reason: 'Consumption', issue_date: new Date().toISOString().slice(0, 10), notes: '' });
    setLines([]);
    loadData();
  };

  const columns: Column<StockIssue>[] = [
    { key: 'issue_number', header: 'Issue No.', sortable: true, render: (i) => <span className="font-semibold text-slate-900">{i.issue_number}</span> },
    { key: 'department', header: 'Department', sortable: true, render: (i) => <Badge variant="info">{i.department}</Badge> },
    { key: 'issue_date', header: 'Date', sortable: true, hideOnMobile: true, render: (i) => formatDate(i.issue_date) },
    { key: 'reason', header: 'Reason', hideOnMobile: true, render: (i) => i.reason || '—' },
    { key: 'total_value', header: 'Value', sortable: true, render: (i) => formatCurrency(i.total_value) },
  ];

  return (
    <div className="animate-page">
      <PageHeader title="Stock Out" description="Issue stock to departments" action={<Button onClick={() => { setShowModal(true); setLines([]); }}><Plus className="h-4 w-4" /> New Issue</Button>} />
      <Card className="p-5">
        <DataTable columns={columns} data={issues} loading={loading} searchPlaceholder="Search issues..." initialSort={{ key: 'issue_date', direction: 'desc' }} />
      </Card>

      <Modal open={showModal} onClose={() => setShowModal(false)} title="New Stock Issue" size="xl" footer={<><Button variant="outline" onClick={() => setShowModal(false)}>Cancel</Button><Button onClick={handleSave} loading={saving}>Save Issue</Button></>}>
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Select label="Department *" value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}>
              {departments.map((d) => <option key={d} value={d}>{d}</option>)}
            </Select>
            <Select label="Reason" value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })}>
              {reasons.map((r) => <option key={r} value={r}>{r}</option>)}
            </Select>
            <Input label="Date" type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })} />
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-bold text-slate-900">Items</h4>
              <Button size="sm" variant="outline" onClick={addLine}><Plus className="h-3.5 w-3.5" /> Add Item</Button>
            </div>
            {lines.length === 0 ? (
              <div className="text-center py-8 text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">No items added.</div>
            ) : (
              <div className="space-y-2">
                {lines.map((l, idx) => (
                  <div key={idx} className="grid grid-cols-2 sm:grid-cols-6 gap-2 items-end p-3 bg-slate-50 rounded-lg">
                    <div className="col-span-2">
                      <label className="text-xs text-slate-500 font-medium">Item</label>
                      <select value={l.item_id} onChange={(e) => updateLine(idx, 'item_id', e.target.value)} className="w-full px-2.5 py-2 rounded-lg border border-slate-300 bg-white text-sm">
                        <option value="">Select</option>
                        {items.map((i) => <option key={i.id} value={i.id}>{i.name} ({formatNumber(i.current_stock)} {i.unit?.symbol})</option>)}
                      </select>
                    </div>
                    <div><label className="text-xs text-slate-500 font-medium">Qty</label><input type="number" value={l.quantity} onChange={(e) => updateLine(idx, 'quantity', e.target.value)} className="w-full px-2.5 py-2 rounded-lg border border-slate-300 bg-white text-sm" /></div>
                    <div><label className="text-xs text-slate-500 font-medium">Unit</label><input value={l.unit} readOnly className="w-full px-2.5 py-2 rounded-lg border border-slate-300 bg-slate-100 text-sm" /></div>
                    <div className="flex-1"><label className="text-xs text-slate-500 font-medium">Total</label><div className="px-2.5 py-2 text-sm font-semibold">{formatCurrency(lineTotal(l))}</div></div>
                    <button onClick={() => removeLine(idx)} className="p-2 text-red-500 hover:bg-red-50 rounded-lg"><Trash2 className="h-4 w-4" /></button>
                  </div>
                ))}
                <div className="flex justify-end"><div className="text-right"><p className="text-xs text-slate-400">Total Value</p><p className="text-lg font-bold">{formatCurrency(grandTotal)}</p></div></div>
              </div>
            )}
          </div>
          <Input label="Notes" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optional notes" />
        </div>
      </Modal>
    </div>
  );
}
